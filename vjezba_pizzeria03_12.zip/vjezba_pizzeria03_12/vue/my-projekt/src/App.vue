<template>
  <div class="pizzeria">
    <header class="header">
      <div class="logo">Pizzeria Nadal</div>
      <nav>
        <ul class="nav-list">
          <li><a href="/" class="nav-link">Početna</a></li>
          <li><a href="/menu" class="nav-link">Menu</a></li>
          <li><a href="/kontakt" class="nav-link">Kontakt</a></li>
        </ul>
      </nav>
    </header>

    <main>
      <h1 class="text-2xl font-bold text-center">Menu</h1>
      <div v-if="loading" class="spinner">Učitavanje...</div>
      <div v-if="error" class="text-red-500">{{ error }}</div>

      <div
        class="pizza-list grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4"
      >
        <div
          v-for="pizza in pizze"
          :key="pizza._id"
          class="pizza-card bg-white p-4 rounded-lg shadow-lg"
        >
          <div class="image-container">
            <img :src="pizza.slika" alt="Pizza" class="pizza-image" />
          </div>
          <h2 class="text-xl font-bold mt-2">{{ pizza.naziv }}</h2>
          <p class="text-gray-700">Cijena: {{ pizza.cijena }} €</p>
          <p class="text-gray-600">Sastojci: {{ pizza.sastojci.join(", ") }}</p>
        </div>
      </div>

      <div class="order-form mt-8">
        <h2 class="text-xl font-bold">Naruči pizze</h2>
        <form @submit.prevent="submitOrder">
          <div class="form-group">
            <label for="kupac">Ime i prezime</label>
            <input
              type="text"
              id="kupac"
              v-model="order.kupac"
              placeholder="Unesite ime i prezime"
              required
            />
          </div>
          <div class="form-group">
            <label for="adresa">Adresa dostave</label>
            <input
              type="text"
              id="adresa"
              v-model="order.adresa"
              placeholder="Unesite adresu"
              required
            />
          </div>
          <div class="form-group">
            <label for="broj_telefona">Broj telefona</label>
            <input
              type="text"
              id="broj_telefona"
              v-model="order.broj_telefona"
              placeholder="Unesite broj telefona"
              required
            />
          </div>

          <div class="form-group">
            <label for="narucene_pizze">Narudžene pizze</label>
            <div v-for="(pizza, index) in order.narucene_pizze" :key="index">
              <select v-model="order.narucene_pizze[index].naziv">
                <option
                  v-for="pizzaOption in pizze"
                  :key="pizzaOption._id"
                  :value="pizzaOption.naziv"
                >
                  {{ pizzaOption.naziv }}
                </option>
              </select>
              <input
                type="number"
                v-model="order.narucene_pizze[index].količina"
                placeholder="Količina"
                min="0.5"
                step="0.5"
              />
              <select v-model="order.narucene_pizze[index].veličina">
                <option value="mala">Mala</option>
                <option value="srednja">Srednja</option>
                <option value="velika">Velika</option>
              </select>
            </div>
            <button type="button" @click="addPizza">Dodaj pizzu</button>
          </div>

          <button type="submit" class="order-button">Naruči pizze</button>
        </form>

        <div v-if="orderError" class="error-message text-red-500">
          {{ orderError }}
        </div>
      </div>
    </main>

    <footer class="footer">
      <div class="footer-content">
        <p>© 2024 Pizzeria Nadal @ Gabriel Nadal</p>
        <div class="social-links">
          <a href="#" class="social-icon">Fb</a>
          <a href="#" class="social-icon">Ig</a>
          <a href="#" class="social-icon">Tw</a>
        </div>
      </div>
    </footer>
  </div>
</template>

<script>
import axios from "axios";

export default {
  data() {
    return {
      pizze: [],
      loading: true,
      error: null,
      order: {
        kupac: "",
        adresa: "",
        broj_telefona: "",
        narucene_pizze: [],
      },
      orderError: null,
    };
  },
  mounted() {
    axios
      .get("http://localhost:3000/pizze")
      .then((response) => {
        this.pizze = response.data;
      })
      .catch((error) => {
        console.error("Greška:", error);
        this.error = "Došlo je do greške pri učitavanju podataka.";
      })
      .finally(() => {
        this.loading = false;
      });
  },
  methods: {
    addPizza() {
      this.order.narucene_pizze.push({
        naziv: this.pizze[0].naziv,
        količina: 1,
        veličina: "mala",
      });
    },

    async submitOrder() {
      try {
        const phoneRegex = /^[0-9\s]+$/;
        if (!phoneRegex.test(this.order.broj_telefona)) {
          this.orderError = "Broj telefona nije ispravan.";
          return;
        }

        const response = await axios.post(
          "http://localhost:3000/narudzbe",
          this.order
        );

        if (response.data) {
          alert(
            "Narudžba je uspješno poslana! ID narudžbe: " +
              response.data.insertedId
          );

          this.order = {
            kupac: "",
            adresa: "",
            broj_telefona: "",
            narucene_pizze: [],
          };
          this.orderError = null;
        }
      } catch (error) {
        console.error("Greška:", error);
        this.orderError =
          error.response?.data?.error ||
          "Došlo je do greške pri slanju narudžbe.";
      }
    },
  },
};
</script>

<style scoped>
.header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  background-color: #333;
  color: white;
  padding: 10px 20px;
}

.logo {
  font-size: 1.5rem;
  font-weight: bold;
}

.nav-list {
  display: flex;
  gap: 20px;
}

.nav-link {
  color: white;
  text-decoration: none;
  font-size: 1rem;
}

.nav-link:hover {
  text-decoration: underline;
}

.footer {
  background-color: #333;
  color: white;
  padding: 20px;
  text-align: center;
  position: relative;
  bottom: 0;
  width: 100%;
}

.footer-content {
  display: flex;
  flex-direction: column;
  gap: 10px;
  align-items: center;
}

.social-links {
  display: flex;
  gap: 15px;
}

.social-icon {
  color: white;
  text-decoration: none;
  font-size: 1.2rem;
}

.social-icon:hover {
  color: #f39c12;
}

/* Main Content */
.pizzeria {
  min-height: 100vh;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  padding: 0 20px;
}

.spinner {
  text-align: center;
  font-size: 1.5rem;
  font-weight: bold;
}

.pizza-list {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
  gap: 1rem;
}

.pizza-card {
  border: 1px solid #ddd;
  padding: 1rem;
  border-radius: 8px;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

.image-container {
  width: 100%;
  height: 200px;
  display: flex;
  justify-content: center;
  align-items: center;
  overflow: hidden;
}

.pizza-image {
  width: auto;
  height: 100%;
  object-fit: contain;
}

.order-form {
  margin-top: 2rem;
  padding: 1rem;
  background-color: #f9f9f9;
  border-radius: 8px;
}

.form-group {
  margin-bottom: 1rem;
}

input,
select {
  width: 100%;
  padding: 0.5rem;
  margin-top: 0.5rem;
  border: 1px solid #ccc;
  border-radius: 4px;
}

button {
  padding: 0.75rem;
  background-color: #007bff;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  margin-top: 1rem;
}

button:hover {
  background-color: #0056b3;
}

.error-message {
  margin-top: 1rem;
  font-weight: bold;
}
</style>
