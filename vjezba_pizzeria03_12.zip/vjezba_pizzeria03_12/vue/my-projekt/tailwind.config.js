/** @type {import('tailwindcss').Config} */
// tailwind.config.js
export default {
  content: ["./src/**/*.{html,vue,js}"], // Ovdje se moraju dodati svi putevi do Vue datoteka
  theme: {
    extend: {},
  },
  plugins: [],
};

